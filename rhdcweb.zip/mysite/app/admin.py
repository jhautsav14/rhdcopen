from django.contrib import admin
from .models import (
    Customer,
    Product,
    Cart,
    OrderPlaced,
    File,
    PrintCart,
    OrderPlacedFile,
    Ticket,
    TicketPlaced
    # FileUpload,
    # UploadFile,
    

)

# Register your models here.
@admin.register(Customer)
class CustomerModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'name', 'locality', 'city', 'zipcode', 'state']

@admin.register(Product)
class ProductModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'title', 'selling_price', 'discounted_price', 'description', 'brand', 'category', 'product_image']

@admin.register(Cart)
class CartModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'product', 'quantity']

@admin.register(PrintCart)
class PrintCartModelAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'file', 'quantity']

@admin.register(OrderPlaced)
class OrderPlacedModelAdmin(admin.ModelAdmin):
    list_display =['id', 'user','order_id', 'product', 'quantity', 'ordered_date', 'status']

# @admin.register(PrintProduct)
# class PrintProductModelAdmin(admin.ModelAdmin):
#     list_display = ['title', 'campus', 'pages', 'print_type', 'print_side', 'product_image']


@admin.register(File)
class FileUploadModelAdmin(admin.ModelAdmin):
    list_display = ['id','user','file','campus_name','print_type','print_color' ,'pages','amount']

@admin.register(OrderPlacedFile)
class OrderPlacedFileModelAdmin(admin.ModelAdmin):
    list_display =['id', 'user','order_id', 'file', 'quantity', 'ordered_date', 'status']

@admin.register(Ticket)
class TicketModelAdmin(admin.ModelAdmin):
    list_display =['id', 'user','passenger_name', 'phone_no', 'bus_from', 'bus_to', 'fare','quantity', 'ordered_date','trip', 'status']


@admin.register(TicketPlaced)
class TicketPlacedModelAdmin(admin.ModelAdmin):
    list_display =['id', 'user','ticket', 'quantity', 'ordered_date', 'status', 'trip']





