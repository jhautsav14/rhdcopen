import json
from unicodedata import category
from django.http import JsonResponse
from django.shortcuts import render , redirect , get_object_or_404
from django.views import View
from .models import Customer, Product, Cart, OrderPlaced , File, PrintCart, OrderPlacedFile , Ticket, TicketPlaced
from .forms import CustomerProfileForm, CustomerRegistrationForm , FileForm , OrderPlacedFileForm ,TicketForm
from django.contrib import messages
from django.db.models import Q
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator

from mysite.settings import RAZORPAY_API_KEY, RAZORPAY_API_SECRET_KEY


from django.http import HttpResponse
from django.template.loader import get_template
from xhtml2pdf import pisa

# def home(request):
#  return render(request, 'app/home.html')

class ProductView(View):
    def get(self, request):
        stationery = Product.objects.filter(category='S')
        return render(request, 'app/home.html',{'stationery':stationery})



# def product_detail(request):
#  return render(request, 'app/productdetail.html')
@method_decorator(login_required, name='dispatch')
class ProductDetailView(View):
    def get(self, request, pk):
        product = Product.objects.get(pk=pk)
        item_already_in_cart = False
        item_already_in_cart = Cart.objects.filter(Q(product=product.id) & Q(user=request.user)).exists()
        return render(request,'app/productdetail.html',{'product':product, 'item_already_in_cart':item_already_in_cart} )

@login_required
def add_to_cart(request):
    user=request.user
    product_id = request.GET.get('prod_id')
    product = Product.objects.get(id=product_id) 
    Cart(user=user, product=product).save()

    return redirect('/cart')



@login_required
def show_cart(request):
    if request.user.is_authenticated:
        user = request.user
        cart = Cart.objects.filter(user=user)
        # pfile = File.objects.filter(user=user)
        
        # print(cart)
        amount = 0.0
        # extra charges can be added 
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == request.user]
        # print(cart_product)
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.discounted_price)
                amount += tempamount
                totalamount =amount 
            return render(request, 'app/addtocart.html', {'carts':cart , 'totalamount':totalamount})
        else:
            return render(request, 'app/emptycart.html') 


def plus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        
        c = Ticket.objects.get(Q(id=prod_id) & Q(user= request.user))
        c.quantity+= 1
        c.save()
        amount = 0.0
        # extra charges can be added 
        total_amount = 0.0
        p = c
        # cart_product = [p for p in Ticket.objects.all() if p.user ==request.user]
        # # print(cart_product)
        # if cart_product:
        #     for p in cart_product:
        tempamount = (p.quantity * p.fare)
        amount += tempamount
        totalamount =amount 

        
        data = {
            'quantity': c.quantity,
            'amount': amount,
            'totalamount': totalamount

        }
        return JsonResponse(data)
       
def minus_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
       
        c = Ticket.objects.get(Q(id=prod_id) & Q(user= request.user))
        c.quantity-=1
        c.save()
        amount = 0.0
        p=c
        # extra charges can be added 
        total_amount = 0.0
        # cart_product = [p for p in Ticket.objects.all() if p.user ==request.user]
        # # print(cart_product)
        # if cart_product:
        # for p in cart_product:
        tempamount = (p.quantity * p.fare)
        amount += tempamount
        totalamount =amount 

        
        data = {
            'quantity': c.quantity,
            'amount': amount,
            'totalamount': totalamount

        }
        return JsonResponse(data)
       
def remove_cart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        
        c = Cart.objects.get(Q(product=prod_id) & Q(user=request.user))
        
        c.delete()
        amount = 0.0
        # extra charges can be added 
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user ==request.user]
        # print(cart_product)
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.product.discounted_price)
                amount += tempamount
                totalamount =amount 
                
                

            
            data = {
                
                'amount': amount,
                'totalamount': totalamount
                
                

            }
            return JsonResponse(data)
       

        



def print(request):
    return render(request, 'app/print.html')


# def profile(request):
#  return render(request, 'app/profile.html')
@login_required
def address(request):
    add = Customer.objects.filter(user=request.user)
     
    return render(request, 'app/address.html',{'add':add, 'active':'btn-primary'})

@login_required
def orders(request):
    op = OrderPlaced.objects.filter(user=request.user).order_by('-id')
    opf = OrderPlacedFile.objects.filter(user=request.user).order_by('-id')

    return render(request, 'app/orders.html',{'order_placed':op, 'order_placed_file':opf})

def printorders(request):
    
    opf = OrderPlacedFile.objects.filter(user=request.user).order_by('-id')

    return render(request, 'app/printorders.html',{ 'order_placed_file':opf, 'active':'btn-primary'})

# def change_password(request):
#  return render(request, 'app/changepassword.html')

def sationery(request, data=None):
    if data == None:
        sationery = Product.objects.filter(category='S')
    return render(request, 'app/sationery.html', {'sationery':sationery})

# def login(request):
#  return render(request, 'app/login.html')

# def customerregistration(request):
#  return render(request, 'app/customerregistration.html')

class CustomerRegistrationView(View):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request,'app/customerregistration.html',{'form':form})
    def post(self, request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Congratulations!! You are one of us Now')
        return render(request,'app/customerregistration.html',{'form':form})

@login_required
def checkout(request):
    user = request.user
    add = Customer.objects.filter(user=user)
    cart_item = Cart.objects.filter(user=user)
    amount = 0.0
    totalamount = 0.0
    cart_product = [p for p in Cart.objects.all() if p.user == user]
        # print(cart_product)
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity * p.product.discounted_price)
            amount += tempamount
        totalamount =amount 
        DATA = {
            "amount": 100*totalamount, #paisa into rupee
            "currency": "INR",
            

            }

        order = client.order.create(data=DATA)
        payment_order_id = order['id']


    return render(request, 'app/checkout.html',{ 'add':add, 'totalamount':totalamount, 'cart_item':cart_item , 'api_key':RAZORPAY_API_KEY,'order_id': payment_order_id,})



    # return render(request, 'app/checkout.html',{ 'add':add, 'totalamount':totalamount, 'cart_item':cart_item})

@login_required
def payment_done(request):
    response = request.POST
    params_dict = {
        'razorpay_payment_id' : response['razorpay_payment_id'],
        'razorpay_order_id': response['razorpay_order_id'],
        'razorpay_signature': response['razorpay_signature'],
    }
    try:
        status = client.utility.verify_payment_signature(params_dict)
        # print('this is response.......', response)
        # print("--------",d)
        #comment on file
        # print(status)
        if status == True:
            user = request.user
            # custid = request.GET.get('custid')
            # customer = Customer.objects.get(id=custid)
            cart = Cart.objects.filter(user=user)
            for c in cart:
                OrderPlaced(user=user,order_id=params_dict['razorpay_order_id'], product=c.product, quantity=c.quantity).save()
                c.delete()
            return redirect("orders")
            
        
    except:
        
        return render(request, 'home.html')   



   

@method_decorator(login_required, name='dispatch')
class ProfileView(View):
    def get(self, request):
        form = CustomerProfileForm()
        return render(request, 'app/profile.html', {'form':form, 'active':'btn-primary'})
    
    def post(self, request):
        form = CustomerProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']
            reg = Customer(user=usr, name=name, locality=locality, city=city, state=state, zipcode=zipcode)
            reg.save()
            messages.success(request, 'Congratulations!! Profile Updated Successfully')
        return render(request, 'app/profile.html', {'form':form, 'active':'btn-primary'})


# def fileupload(request):
#         if request.method =="POST" :
#             form = FileForm(request.POST)
#             user = request.user
#             file = request.FILES.getlist("uploadfiles")
#             campus_name = form.cleaned_data['campus_name']
#             print_type = form.cleaned_data['print_type']
#             print_color = form.cleaned_data['print_color']
#             pages = form.cleaned_data['pages']
#             filesave = File(user=user, file=file, campus_name=campus_name, print_type=print_type, print_color=print_color, pages=pages)
#             filesave.save()
#             print('done')
#             return render(request, 'app/orders.html')

#         if request.method =="GET":
#             form = FileForm()
#             return render(request, 'app/print.html',{'form':form})


@method_decorator(login_required, name='dispatch')         
class PrintFileView(View):
    def get(self, request):
        form = FileForm()
        return render(request, 'app/print.html',{'form':form})
        
    def post(self, request):
        
        form = FileForm(request.POST)

        user = request.user
        file = request.FILES.get("file")
        campus_name = request.POST.get('campus_name')
        print_type = request.POST.get('print_type')
        print_color = request.POST.get('print_color')
        pages = request.POST.get('pages')
        
        if print_color == "Color":
            amount = int(pages)*7
        else:
            amount = int(pages)*2

        new_file = File(user=user, file=file, campus_name=campus_name, print_type=print_type, print_color=print_color, pages=pages, amount=amount)
        new_file.save()

        
        
       
        # user = request.user
        # file = request.FILES.getlist("file")
        # campus_name = form.cleaned_data['campus_name']
        # print_type = form.cleaned_data['print_type']
        # print_color = form.cleaned_data['print_color']
        # pages = form.cleaned_data['pages']

        # new_file = File(user=user, file=file, campus_name=campus_name, print_type=print_type, print_color=print_color, pages=pages)
        # new_file.save()
        
        messages.success(request, 'Congratulations!! Profile Updated Successfully')
        return redirect('printview')


        


    #     return render(request, 'app/print.html')
@login_required
def print_view(request):
    if request.user.is_authenticated:
        user=request.user
        
        product = File.objects.filter(user=user).order_by('-id')
        product_id = request.GET.get('prod_id')
        # for c in product:
        #     PrintCart(user=user, product=c.id).save()
            
        
        # cart = Cart.objects.filter(user=user)
        # pfile = File.objects.filter(user=user)
        
        # print(cart)
       
        # printproduct = Product.objects.get(id=) 
        # PrintCart(user=user, product=printproduct).save()

        
        return render(request, 'app/printview.html',{'product':product})
@login_required
def add_print_cart(request):
    user = request.user
    # product = File.objects.filter(user=user)
    product_id =request.GET.get('prod_id')
    product = File.objects.get(id=product_id) 
    PrintCart(user=user, file=product).save()

    return redirect('/pcart')
    

    


@login_required
def print_show_cart(request):
    if request.user.is_authenticated:
        user = request.user
        cart = PrintCart.objects.filter(user=user)
        # pfile = File.objects.filter(user=user)
        
        # print(cart)
        amount = 0.0
        # extra charges can be added 
        total_amount = 0.0
        cart_product = [p for p in PrintCart.objects.all() if p.user == request.user]
        # print(cart_product)
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * p.file.amount)
                amount += tempamount
                totalamount =amount 
            return render(request, 'app/printcart.html', {'carts':cart , 'totalamount':totalamount})
        else:
            return render(request, 'app/emptycart.html') 
       

@login_required
def printcheckout(request):
    user = request.user
    add = Customer.objects.filter(user=user)
    cart_item = PrintCart.objects.filter(user=user)
    amount = 0.0
    totalamount = 0.0
    cart_product = [p for p in PrintCart.objects.all() if p.user == user]
        # print(cart_product)
    if cart_product:
        for p in cart_product:
            tempamount = (p.quantity * p.file.amount)
            amount += tempamount
        totalamount =amount 

        DATA = {
            "amount": 100*totalamount, #paisa into rupee
            "currency": "INR",
            

            }

        order = client.order.create(data=DATA)
        payment_order_id = order['id']


    return render(request, 'app/printcheckout.html',{ 'add':add, 'totalamount':totalamount, 'cart_item':cart_item , 'api_key':RAZORPAY_API_KEY,'order_id': payment_order_id,})

@login_required
def print_payment_done(request):
    
    # custid = request.GET.get('custid')
    # customer = Customer.objects.get(id=custid)
    

    response = request.POST
    params_dict = {
        'razorpay_payment_id' : response['razorpay_payment_id'],
        'razorpay_order_id': response['razorpay_order_id'],
        'razorpay_signature': response['razorpay_signature'],
    }
    try:
        status = client.utility.verify_payment_signature(params_dict)
        # print('this is response.......', response)
        # print("--------",d)
        #comment on file
        # print(status)
        if status == True:
            user = request.user
            cart = PrintCart.objects.filter(user=user)
            for c in cart:
                OrderPlacedFile(user=user,order_id=params_dict['razorpay_order_id'] ,file=c.file, quantity=c.quantity).save()
                c.delete()
            return redirect("orders")
        
    except:
        
        return render(request, 'home.html')   

    


class OrderPlacedView(View):
    def get(self,request):
        form = OrderPlacedFileForm()
        opf = OrderPlacedFile.objects.filter(~Q(status='Delivered'))
        op = OrderPlaced.objects.filter(~Q(status='Delivered'))
        return render(request,'app/orderview.html', {'form': form , 'opf': opf ,'op':op})

    # def post(self, request ):
    #     form = OrderPlacedFileForm(request.POST)
    #     if form.is_valid():
    #         user =  request.user
    #         status = request.POST.get("status")
    #         file_id = request.GET.get("prod_id")
    #         id = int(file_id)
    #         # order = OrderPlacedFile.objects.get(id=file_id)
            
            
    #         update = OrderPlacedFile.objects.get(pk=id)
    #         fm = OrderPlacedFileForm(request.POST,instance=update)
    #         if fm.is_valid():
    #             fm.save()
                
    #         return redirect('orderview')

def orderupdate(request,id , pid):
    if request.method == 'POST':
        st = request.POST.get("status")
        file_id = request.GET.get("prod_id")
        print(file_id)
        
        pi =OrderPlacedFile.objects.get(pk=id)
        fm = OrderPlacedFileForm(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
            if st == "Cancel":
                file_del = File.objects.filter(id=pid)
                file_del.delete()


        return redirect('orderview')
                
def orders_by_delivered(request):
    if request.method == 'GET':
        opf = OrderPlacedFile.objects.filter(status='Delivered')
        op = OrderPlaced.objects.filter(status='Delivered')


    return render(request,'app/order_delivered.html', { 'opf': opf , 'op':op})

def orders_by_ready(request):
    if request.method == 'GET':
        form = OrderPlacedFileForm()
        opf = OrderPlacedFile.objects.filter(status='Ready')
        op = OrderPlaced.objects.filter(status='Ready')


    return render(request,'app/order_ready.html', { 'opf': opf , 'op':op , 'form': form})

def prod_orderupdate(request,id ):
    if request.method == 'POST':
        st = request.POST.get("status")
       
        
        pi =OrderPlaced.objects.get(pk=id)
        fm = OrderPlacedFileForm(request.POST,instance=pi)
        if fm.is_valid():
            fm.save()
            


        return redirect('orderview')


       
def remove_pcart(request):
    if request.method == 'GET':
        prod_id = request.GET['prod_id']
        
        
        c = File.objects.get(Q(id=prod_id) & Q(user= request.user))
        
        c.delete()
        return redirect('pcart')


# Bus route Bhithamore to patna
@method_decorator(login_required, name='dispatch')         
class TicketView(View):
    def get(self, request):
        form = TicketForm()
        return render(request, 'app/ticket.html',{'form':form})
        
    def post(self, request):
        
        form = TicketForm(request.POST)

        user = request.user
        passenger_name = request.POST.get("passenger_name")
        phone_no = request.POST.get('phone_no')
        bus_from = request.POST.get('bus_from')
        bus_to = request.POST.get('bus_to')
        fare = request.POST.get('fare')
        # route of bus 
        trip = "Bhithamore to Patna"
        
        
        new_file = Ticket(user=user, passenger_name=passenger_name, phone_no=phone_no, bus_from=bus_from, bus_to=bus_to, fare=fare ,trip=trip)
        new_file.save()

        
        
       
        # user = request.user
        # file = request.FILES.getlist("file")
        # campus_name = form.cleaned_data['campus_name']
        # print_type = form.cleaned_data['print_type']
        # print_color = form.cleaned_data['print_color']
        # pages = form.cleaned_data['pages']

        # new_file = File(user=user, file=file, campus_name=campus_name, print_type=print_type, print_color=print_color, pages=pages)
        # new_file.save()
        
        messages.success(request, 'Congratulations!! Profile Updated Successfully')
        return redirect('ticketmain')

# Bus route Patna to Bhithamore
@method_decorator(login_required, name='dispatch')         
class TicketPBView(View):
    def get(self, request):
        form = TicketForm()
        return render(request, 'app/ticketPB.html',{'form':form})
        
    def post(self, request):
        
        form = TicketForm(request.POST)

        user = request.user
        passenger_name = request.POST.get("passenger_name")
        phone_no = request.POST.get('phone_no')
        bus_from = request.POST.get('bus_from')
        bus_to = request.POST.get('bus_to')
        fare = request.POST.get('fare')
        # route of bus 
        trip = "Patna to Bhithamore"
        
        
        new_file = Ticket(user=user, passenger_name=passenger_name, phone_no=phone_no, bus_from=bus_from, bus_to=bus_to, fare=fare ,trip=trip)
        new_file.save()

        
        
       
        
        
        messages.success(request, 'Congratulations!! Profile Updated Successfully')
        return redirect('ticketmain')




@login_required
def ticket_main(request):
    if request.user.is_authenticated:
        user=request.user
        
        product = Ticket.objects.filter(status = 'Pending').order_by('-id')
        
        # for c in product:
        #     PrintCart(user=user, product=c.id).save()
            
        
        # cart = Cart.objects.filter(user=user)
        # pfile = File.objects.filter(user=user)
        
        # print(cart)
       
        # printproduct = Product.objects.get(id=) 
        # PrintCart(user=user, product=printproduct).save()

        
        return render(request, 'app/ticketmain.html',{'product':product})



@login_required
def ticket_booked(request, *args, **kwargs):
    if request.user.is_authenticated:
        user=request.user
        pk = kwargs.get('pk')
        
        cart = Ticket.objects.get(Q(id=pk) & Q(user=user) )
         # print(cart)
        amount = 0.0
        # extra charges can be added 
        total_amount = 0.0
        p = cart
        # print(cart_product)
        
        tempamount = (p.quantity * p.fare)
        amount += tempamount
        totalamount =amount 
        return render(request, 'app/ticketbooked.html', {'cart':cart , 'totalamount':totalamount})
    else:
        return render(request, 'app/emptycart.html') 
        
        

        
        return render(request, 'app/ticketbooked.html',{'cart':product})

@login_required
# def ticket_print(request):
#     if request.user.is_authenticated:
#         user=request.user
        
#         product = Ticket.objects.filter(user=user).order_by('-id')
#         product_id = request.GET.get('prod_id')
#         # for c in product:
#         #     PrintCart(user=user, product=c.id).save()
            
        
#         # cart = Cart.objects.filter(user=user)
#         # pfile = File.objects.filter(user=user)
        
#         # print(cart)
       
#         # printproduct = Product.objects.get(id=) 
#         # PrintCart(user=user, product=printproduct).save()

        
#         return render(request, 'app/ticketbooked.html',{'product':product})



def ticket_print(request , *args, **kwargs):
    pk = kwargs.get('pk')
    passenger = get_object_or_404(Ticket, pk=pk)
    user = request.user
        # custid = request.GET.get('custid')
        # customer = Customer.objects.get(id=custid)
        
    cart = Ticket.objects.get(Q(id=pk) & Q(user=user))
    
    TicketPlaced(user=user, ticket=cart, quantity=cart.quantity , trip=cart.trip).save()
    Ticket.objects.filter(pk=pk).update(status = "Paid")
    
    
    

        
    


    

    template_path = 'app/ticketprint.html'
    context = {'passenger': passenger}
    # Create a Django response object, and specify content_type as pdf
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename="report.pdf"'
    # find the template and render it.
    template = get_template(template_path)
    html = template.render(context)

    # create a pdf
    pisa_status = pisa.CreatePDF(
       html, dest=response)
    # if error then show some funny view
    if pisa_status.err:
       return HttpResponse('We had some errors <pre>' + html + '</pre>')
    return response

    

def ticket_dashboard(request):
    if request.user.is_authenticated:
        db = TicketPlaced.objects.all()

        return render(request, "app/dashboard.html", {'db':db})

